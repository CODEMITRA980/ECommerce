# Ecommerce-Website-Using-Nodejs-MongoDB
This is a ecommerce website made using nodejs and mongodb atlas . Admin can add/delete any product .
Users can view categories wise products.
Product can be decreased admin side when someone buy it by using their paypal account( sandbox paypal used for testing only) .   
Please change the username and password in all models by your username and password . 
Please make a admin by changing the admin number to 1 in cmscart and user collection collection in database. Then functionality of admin is activated for that user.


Website 
tliq.herokuapp.com
